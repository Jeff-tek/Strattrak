// src/main.tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import StrategyTracker from './StrategyTracker' // or './App' if you renamed it
import './index.css' // Ensure Tailwind styles are imported

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <StrategyTracker />
  </React.StrictMode>,
)