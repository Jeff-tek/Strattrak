// --- START OF FILE strategy_monitor.tsx (modified) ---

import React, { useState, ChangeEvent } from 'react';
import { Calendar, Lock, AlertTriangle, TrendingUp, Target, DollarSign } from 'lucide-react';

interface Trade {
  id: number;
  date: string;
  notes: string;
  profitLoss: number;
  screenshot: string | null;
  tradeNumber: number;
}

interface Strategy {
  id: number;
  name: string;
  description: string;
  commitmentDays: number;
  minTrades: number;
  startDate: string;
  endDate: string;
  currentTrades: number;
  temptationAttempts: number;
  trades: Trade[];
  totalPnL: number;
  status: 'active'; // Could be expanded (e.g., 'completed', 'abandoned')
  lastTemptation?: {
    reason: string;
    date: string;
  };
}

// Renamed StrategyTracker to App for common Vite setup, can be named as you like
const StrategyTracker = () => {
  const [activeStrategy, setActiveStrategy] = useState<Strategy | null>(null);
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [showCommitModal, setShowCommitModal] = useState(false);
  const [showTemptationModal, setShowTemptationModal] = useState(false);
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [temptationReason, setTemptationReason] = useState('');
  const [newTrade, setNewTrade] = useState<{
    notes: string;
    profitLoss: string; // Keep as string for input, parse on submit
    screenshot: string | null;
  }>({
    notes: '',
    profitLoss: '',
    screenshot: null
  });
  const [newStrategy, setNewStrategy] = useState<{
    name: string;
    description: string;
    commitmentDays: number;
    minTrades: number;
  }>({
    name: '',
    description: '',
    commitmentDays: 30,
    minTrades: 20
  });

  // Note: Data will persist only during this session
  // In a real app, this would connect to a database

  const commitToStrategy = () => {
    if (!newStrategy.name.trim()) {
      alert("Strategy name cannot be empty."); // Simple validation feedback
      return;
    }
    
    const strategy: Strategy = {
      ...newStrategy,
      id: Date.now(),
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + newStrategy.commitmentDays * 24 * 60 * 60 * 1000).toISOString(),
      currentTrades: 0,
      temptationAttempts: 0,
      trades: [],
      totalPnL: 0,
      status: 'active'
    };
    
    setStrategies(prev => [...prev, strategy]);
    setActiveStrategy(strategy);
    setShowCommitModal(false);
    setNewStrategy({ name: '', description: '', commitmentDays: 30, minTrades: 20 }); // Reset form
  };

  const handleScreenshotUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event: ProgressEvent<FileReader>) => {
        if (event.target?.result) {
          setNewTrade(prev => ({ ...prev, screenshot: event.target.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const logTrade = () => {
    if (!activeStrategy) return;
    
    const trade: Trade = {
      id: Date.now(),
      date: new Date().toISOString(),
      notes: newTrade.notes,
      profitLoss: parseFloat(newTrade.profitLoss) || 0,
      screenshot: newTrade.screenshot,
      tradeNumber: activeStrategy.currentTrades + 1
    };
    
    const updatedStrategy: Strategy = {
      ...activeStrategy,
      currentTrades: activeStrategy.currentTrades + 1,
      trades: [...(activeStrategy.trades || []), trade],
      totalPnL: (activeStrategy.totalPnL || 0) + trade.profitLoss
    };
    
    setActiveStrategy(updatedStrategy);
    setStrategies(prev => prev.map(s => s.id === updatedStrategy.id ? updatedStrategy : s));
    setNewTrade({ notes: '', profitLoss: '', screenshot: null }); // Reset form
    setShowTradeModal(false);
  };

  const handleTemptation = () => {
    if (!activeStrategy || !temptationReason.trim()) {
        alert("Please provide a reason for the temptation."); // Simple validation
        return;
    }
    
    const updatedStrategy: Strategy = {
      ...activeStrategy,
      temptationAttempts: activeStrategy.temptationAttempts + 1,
      lastTemptation: {
        reason: temptationReason,
        date: new Date().toISOString()
      }
    };
    
    setActiveStrategy(updatedStrategy);
    setStrategies(prev => prev.map(s => s.id === updatedStrategy.id ? updatedStrategy : s));
    setTemptationReason(''); // Reset reason
    setShowTemptationModal(false);
  };

  const getDaysRemaining = (strategy: Strategy | null): number => {
    if (!strategy) return 0;
    const end = new Date(strategy.endDate);
    const now = new Date();
    return Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  };

  const getProgressPercentage = (strategy: Strategy | null): number => {
    if (!strategy) return 0;

    const { commitmentDays, minTrades, currentTrades } = strategy;
    const daysRemaining = getDaysRemaining(strategy);

    if (commitmentDays === 0 && minTrades === 0) return 100;

    let timeProgress = 0;
    if (commitmentDays > 0) {
      timeProgress = ((commitmentDays - daysRemaining) / commitmentDays) * 100;
    } else {
      timeProgress = 100; 
    }

    let tradeProgress = 0;
    if (minTrades > 0) {
      tradeProgress = (currentTrades / minTrades) * 100;
    } else {
      tradeProgress = 100;
    }
    
    if (commitmentDays === 0) return Math.min(100, tradeProgress);
    if (minTrades === 0) return Math.min(100, timeProgress);

    return Math.min(100, Math.max(timeProgress, tradeProgress));
  };

  const isCommitmentComplete = (strategy: Strategy | null): boolean => {
    if (!strategy) return false;
    
    const { commitmentDays, minTrades, currentTrades } = strategy;
    
    if (commitmentDays === 0 && minTrades === 0) return true;

    const daysAreComplete = commitmentDays === 0 ? true : getDaysRemaining(strategy) === 0;
    const tradesAreComplete = minTrades === 0 ? true : currentTrades >= minTrades;

    if (commitmentDays === 0) return tradesAreComplete;
    if (minTrades === 0) return daysAreComplete;
    
    return daysAreComplete || tradesAreComplete;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Strategy Commitment Tracker
          </h1>
          <p className="text-gray-400">Stop strategy-hopping. Start succeeding.</p>
        </div>

        {/* Active Strategy Card */}
        {activeStrategy ? (
          <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-blue-400">Current Strategy</h2>
              <div className="flex items-center text-green-400">
                <Lock className="w-5 h-5 mr-2" />
                <span>Locked In</span>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold mb-2">{activeStrategy.name}</h3>
                <p className="text-gray-400 mb-4 whitespace-pre-wrap">{activeStrategy.description}</p> {/* Added whitespace-pre-wrap */}
                
                <div className="space-y-3">
                  <div className="flex items-center text-gray-300">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>{getDaysRemaining(activeStrategy)} days remaining</span>
                  </div>
                  <div className="flex items-center text-gray-300">
                    <Target className="w-4 h-4 mr-2" />
                    <span>{activeStrategy.currentTrades}/{activeStrategy.minTrades} trades completed</span>
                  </div>
                  {activeStrategy.totalPnL !== undefined && (
                    <div className={`flex items-center ${activeStrategy.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      <DollarSign className="w-4 h-4 mr-2" />
                      <span>P&L: ${activeStrategy.totalPnL.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex items-center text-yellow-400">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    <span>{activeStrategy.temptationAttempts} temptation attempts logged</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progress</span>
                    <span>{Math.round(getProgressPercentage(activeStrategy))}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${getProgressPercentage(activeStrategy)}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <button
                    onClick={() => setShowTradeModal(true)}
                    className="w-full bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors"
                  >
                    Log Trade
                  </button>
                  
                  <button
                    onClick={() => setShowTemptationModal(true)}
                    className="w-full bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-lg transition-colors"
                  >
                    I Want to Switch Strategies
                  </button>
                </div>
              </div>
            </div>
            
            {isCommitmentComplete(activeStrategy) && (
              <div className="mt-6 p-4 bg-green-900/30 border border-green-500 rounded-lg">
                <h3 className="text-green-400 font-semibold mb-2">🎉 Commitment Complete!</h3>
                <p className="text-gray-300">You can now switch strategies or extend this commitment.</p>
                <button
                  onClick={() => {
                    // setActiveStrategy(null); // Optional: clear active strategy immediately
                    setShowCommitModal(true);
                  }}
                  className="mt-3 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
                >
                  Start New Strategy
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-gray-800 rounded-xl p-8 mb-8 border border-gray-700 text-center">
            <TrendingUp className="w-16 h-16 mx-auto mb-4 text-blue-400" />
            <h2 className="text-2xl font-bold mb-4">No Active Strategy</h2>
            <p className="text-gray-400 mb-6">Commit to a trading strategy and stick with it for meaningful results.</p>
            <button
              onClick={() => setShowCommitModal(true)}
              className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Commit to a Strategy
            </button>
          </div>
        )}

        {/* Strategy History */}
        {strategies.length > 0 && ( // Only show history if there are strategies
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold mb-4">Strategy History</h2>
            <div className="space-y-3">
              {strategies.map(strategy => (
                <div key={strategy.id} className="bg-gray-700 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold">{strategy.name}</h3>
                      <p className="text-sm text-gray-400 whitespace-pre-wrap">{strategy.description}</p> {/* Added whitespace-pre-wrap */}
                    </div>
                    <div className="text-right text-sm">
                      <div className="text-gray-300">{strategy.currentTrades} trades</div>
                      <div className="text-yellow-400">{strategy.temptationAttempts} temptations</div>
                      {strategy.totalPnL !== undefined && (
                        <div className={strategy.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}>
                          ${strategy.totalPnL.toFixed(2)}
                        </div>
                      )}
                      { isCommitmentComplete(strategy) && strategy.id !== activeStrategy?.id && (
                        <div className="text-green-400 mt-1 text-xs">(Completed)</div>
                      )}
                    </div>
                  </div>
                  
                  {strategy.trades && strategy.trades.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-600">
                      <h4 className="text-sm font-medium mb-2">Recent Trades ({strategy.trades.length}):</h4>
                      <div className="space-y-2">
                        {strategy.trades.slice(-3).reverse().map(trade => (
                          <div key={trade.id} className="bg-gray-600 p-2 rounded text-xs">
                            <div className="flex justify-between items-start">
                              <div className="flex-1">
                                <div className="font-medium">Trade #{trade.tradeNumber} (on {new Date(trade.date).toLocaleDateString()})</div>
                                {trade.notes && <div className="text-gray-300 mt-1 whitespace-pre-wrap">{trade.notes}</div>} {/* Added whitespace-pre-wrap */}
                              </div>
                              <div className={`ml-2 font-bold ${trade.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                ${trade.profitLoss.toFixed(2)}
                              </div>
                            </div>
                            {trade.screenshot && (
                              <div className="mt-2">
                                <img 
                                  src={trade.screenshot} 
                                  alt={`Trade ${trade.tradeNumber} screenshot`}
                                  className="w-full h-20 object-cover rounded cursor-pointer"
                                  onClick={() => window.open(trade.screenshot!, '_blank')} // Added non-null assertion as screenshot presence is checked
                                />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Trade Logging Modal */}
      {showTradeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-700 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold mb-4 text-green-400">📊 Log Trade</h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="tradeNotes" className="block text-sm font-medium mb-2">Trade Notes</label>
                <textarea
                  id="tradeNotes"
                  value={newTrade.notes}
                  onChange={(e) => setNewTrade(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white h-20"
                  placeholder="What happened in this trade? Entry/exit points, market conditions, etc."
                />
              </div>
              
              <div>
                <label htmlFor="tradePnL" className="block text-sm font-medium mb-2">Profit/Loss ($)</label>
                <input
                  id="tradePnL"
                  type="number"
                  step="0.01"
                  value={newTrade.profitLoss}
                  onChange={(e) => setNewTrade(prev => ({ ...prev, profitLoss: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  placeholder="e.g., 50.25 or -23.10"
                />
              </div>
              
              <div>
                <label htmlFor="tradeScreenshot" className="block text-sm font-medium mb-2">Screenshot (Optional)</label>
                <input
                  id="tradeScreenshot"
                  type="file"
                  accept="image/*"
                  onChange={handleScreenshotUpload}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white file:bg-blue-600 file:border-0 file:text-white file:px-3 file:py-1 file:rounded file:mr-3"
                />
                {newTrade.screenshot && (
                  <div className="mt-2">
                    <img 
                      src={newTrade.screenshot} 
                      alt="Trade preview" 
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => {
                  setShowTradeModal(false);
                  setNewTrade({ notes: '', profitLoss: '', screenshot: null }); // Reset form on cancel
                }}
                className="flex-1 bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={logTrade}
                className="flex-1 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors"
              >
                Log Trade
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Commit Modal */}
      {showCommitModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-700">
            <h3 className="text-xl font-bold mb-4">Commit to a Strategy</h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="strategyName" className="block text-sm font-medium mb-2">Strategy Name</label>
                <input
                  id="strategyName"
                  type="text"
                  value={newStrategy.name}
                  onChange={(e) => setNewStrategy(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  placeholder="e.g., RSI Divergence Strategy"
                />
              </div>
              
              <div>
                <label htmlFor="strategyDescription" className="block text-sm font-medium mb-2">Description</label>
                <textarea
                  id="strategyDescription"
                  value={newStrategy.description}
                  onChange={(e) => setNewStrategy(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white h-20"
                  placeholder="Brief description of your strategy..."
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="commitmentDays" className="block text-sm font-medium mb-2">Commitment Days</label>
                  <input
                    id="commitmentDays"
                    type="number"
                    min="0"
                    value={newStrategy.commitmentDays}
                    onChange={(e) => setNewStrategy(prev => ({ ...prev, commitmentDays: parseInt(e.target.value, 10) || 0 }))}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label htmlFor="minTrades" className="block text-sm font-medium mb-2">Min Trades</label>
                  <input
                    id="minTrades"
                    type="number"
                    min="0"
                    value={newStrategy.minTrades}
                    onChange={(e) => setNewStrategy(prev => ({ ...prev, minTrades: parseInt(e.target.value, 10) || 0 }))}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => {
                  setShowCommitModal(false);
                  setNewStrategy({ name: '', description: '', commitmentDays: 30, minTrades: 20 }); // Reset form on cancel
                }}
                className="flex-1 bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={commitToStrategy}
                className="flex-1 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
              >
                Commit & Lock In
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Temptation Modal */}
      {showTemptationModal && activeStrategy && ( // Ensure activeStrategy exists when showing this modal
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-700">
            <h3 className="text-xl font-bold mb-4 text-yellow-400">⚠️ Strategy Switch Temptation</h3>
            <p className="text-gray-300 mb-4">
              Before you switch, tell us why. This helps you recognize patterns in your decision-making.
            </p>
            
            <label htmlFor="temptationReason" className="sr-only">Reason for temptation</label>
            <textarea
              id="temptationReason"
              value={temptationReason}
              onChange={(e) => setTemptationReason(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white h-24 mb-4"
              placeholder="Why do you want to switch strategies right now? Be honest..."
            />
            
            <div className="bg-red-900/30 border border-red-500 rounded-lg p-3 mb-4">
              <p className="text-red-300 text-sm">
                <strong>Remember:</strong> You have {getDaysRemaining(activeStrategy)} days and {Math.max(0, activeStrategy.minTrades - activeStrategy.currentTrades)} trades left in your commitment.
              </p>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => setShowTemptationModal(false)}
                className="flex-1 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors"
              >
                Stay Committed
              </button>
              <button
                onClick={handleTemptation}
                className="flex-1 bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-lg transition-colors"
              >
                Log Temptation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StrategyTracker;
// --- END OF FILE strategy_monitor.tsx (modified) ---